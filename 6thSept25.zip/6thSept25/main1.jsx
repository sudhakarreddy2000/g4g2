import {createRoot} from 'react-dom/client'
createRoot(document.getElementById('root')).render(
  <>
  <h1>Welcome to react</h1>
  <h2>React </h2>
  <h3>{30+30}</h3>
   </>
)