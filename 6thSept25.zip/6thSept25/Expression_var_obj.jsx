import {createRoot} from 'react-dom/client'
let uid="React";
let pwd="App";
let age=22
let students=['Ajay','Vijay','Seetha','Geetha']
createRoot(document.getElementById('root')).render(
  <>
  <h3>{uid}</h3>
  <h3>{pwd}</h3>
  <h3>{age}</h3>
  <h3>{students[0]}</h3>
  </>
)