import {createRoot} from 'react-dom/client'
let obj=new Date();
let h=obj.getHours();
let message;
if(h<=12){
  message="Good morning"
}else if(h>12 && h<=17){
  message="Good Afternoon"
}else{
  message="Good Evening"
}
createRoot(document.getElementById('root')).render(
  <>
  <h1>Hello {message}</h1>
  </>
)