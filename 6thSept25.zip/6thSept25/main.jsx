import {createRoot} from 'react-dom/client'
import pic from './images/flower.jpg'
const clr={
  color:'green',
  fontFamily:'arial'
}
createRoot(document.getElementById('root')).render(
  <>
  <h1 style={{color:'red'}}>Hello </h1>
  <h2 style={clr}>css using object</h2>
  <h3>image from public foloder can be accessed directly</h3>
  <img src='vite.svg' alt=""/>
  <h3>images from src folder has to be imported first then 
    place it in expression</h3>
  <img src={pic} alt=""/>
  </>
)