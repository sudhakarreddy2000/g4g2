var x="Learning node modules"
console.log("Wecome to Node js")
console.log(x)