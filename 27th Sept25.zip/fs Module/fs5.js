const fs=require('fs');
fs.mkdir('temdir2',function(err){
    if(!err){
        console.log("Directory is created..")
    }else{
        console.log(err)
    }
})

