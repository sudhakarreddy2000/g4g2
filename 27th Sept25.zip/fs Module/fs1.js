const fs=require('fs')
fs.readFile(__dirname+"/demo1.txt",'utf8',function(data,err){
    if(!err){
        console.log(data)
    }else{
        console.log(err)
    }
});