const fs=require('fs');
fs.unlink('demo2.txt',function(err){
    if(!err){
        console.log("File deleted..")
    }else{
        console.log(err)
    }
})

