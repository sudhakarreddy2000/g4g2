const fs=require('fs');
fs.writeFile('demo2.txt','nodejs is server coding',function(err){
if(!err){
    console.log("File has been created")
}else{
    console.log("Some error")
}
})