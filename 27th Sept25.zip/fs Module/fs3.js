const fs=require('fs');
fs.appendFile(__dirname+'/demo1.txt', "Its raing in Hyd",function(err){
    if(!err){
        console.log("File is appended")
    }else{
        console.log(err)
    }
})
