const fs=require('fs');
fs.rmdir('temdir',function(err){
    if(!err){
        console.log("Directory is deleted..")
    }else{
        console.log(err)
    }
})

