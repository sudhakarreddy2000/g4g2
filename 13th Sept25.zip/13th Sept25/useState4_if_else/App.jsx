import React, {useState} from 'react'
export default function App() {
  const [state, setState]=useState("On")
 
  function Test(){
    if(state=="On"){
      setState("Off")
    }else{
      setState("On")
    }
  }

  return (
    <div>
      <h1>App component</h1>
      <h3>{state}</h3>
     <button onClick={Test}> On/Off </button>

    </div>
  )
}
