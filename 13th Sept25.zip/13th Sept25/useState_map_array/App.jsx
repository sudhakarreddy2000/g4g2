import React, {useState} from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
export default function App() {
  let emp=['Anil','Sunil','Hema','Seetha']
  const [data, setData]=useState(emp)
  return (
    <>
  {data.map((item)=><div className='bg-success p-3 m-2'>{item}</div>)}   
    </>
  )
}
