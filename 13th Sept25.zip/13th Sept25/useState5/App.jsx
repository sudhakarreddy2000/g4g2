import React, {useState} from 'react'
export default function App() {
  let uid="React"
  let uid1="SPA"
  const [state, setState]=useState(uid)
const Test=()=>{
  setState(uid1)
}
  return (
    <div>
      <h1>App component</h1>
      <h3>{state}</h3>
     <button onClick={Test}> On/Off </button>

    </div>
  )
}
