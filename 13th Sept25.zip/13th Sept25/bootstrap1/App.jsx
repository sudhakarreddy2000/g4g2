import React from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import pic from './images/flower.jpg'
export default function App() {

  return (
    <div>
      <h1 className="text-danger">App component</h1>
      <img src={pic} alt="" className='img-fluid'/>
    </div>
  )
}
