import React, {useState} from 'react'
export default function App() {
  const [state, setState]=useState(100)
 
  function Test(){
    setState(state+1)
  }
  const Test1=()=>{
    setState(state-1)
  }
  return (
    <div>
      <h1>App component</h1>
      <h3>{state}</h3>
     <button onClick={Test}> + </button>
      <button onClick={Test1}>- </button>
    </div>
  )
}
