import React, {useState} from 'react'

export default function App() {
  let emp=['Anil','Sunil','Hema','Seetha']
  const [data, setData]=useState(emp)
  return (
    <>
    {/* <h3>{data}</h3> */}
    <ul>
    {data.map((item)=><li>{item}</li>)}
    </ul>
    </>
  )
}
