import React, {useState} from 'react'

export default function App() {
  const [state, setState]=useState("Learning React Application")
  const [name, setName]=useState("Single Page Application")
  return (
    <div>
      <h1>App component</h1>
      <h3>{state}</h3>
      <h3>{name}</h3>
    </div>
  )
}
