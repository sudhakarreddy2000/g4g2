import React, {useState} from 'react'

export default function App() {
  const [state, setState]=useState("Learning React Application")
  function Test(){
    setState("Single Page Application")
  }
  return (
    <div>
      <h1>App component</h1>
      <h3>{state}</h3>
     <button onClick={Test}>update state </button>
    </div>
  )
}
