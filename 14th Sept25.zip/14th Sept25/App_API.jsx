import React, { useState } from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'

export default function App() {
  fetch('https://jsonplaceholder.typicode.com/todos')
      .then(response => response.json())
      //.then(json => console.log(json))
      .then(json =>setState(json) )
  const [state, setState] = useState([])
  return (
    <>
    <ul>
    {state.map((item)=><li>{item.title}</li>)}
    </ul>
    </>
  )
}
