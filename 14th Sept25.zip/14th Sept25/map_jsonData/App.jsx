import React, {useState} from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import Data from './Data.json'
export default function App() {

  const [state, setState]=useState(Data)
  return (
    <>
   {/* {state.map((item)=><li>{item.name}</li>)} */}

   <table className='table'>
    <tr>
      <td>Id</td>
      <td>Name</td>
      <td>Place</td>
      <td>Age</td>
    </tr>
   
   {state.map((item)=><tr>
    <td>{item.id}</td>
     <td>{item.name}</td>
      <td>{item.place}</td>
       <td>{item.age}</td>
    </tr>)}


   </table>
    </>
  )
}
