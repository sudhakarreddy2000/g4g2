import React, { useState, useEffect } from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'

export default function App() {
  const [state, setState] = useState([])
  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then(response => response.json())
      //.then(data => console.log(data));
      .then(data => setState(data));
  }, [])
  return (
    <>
      <div className='container'>
        <div className='row'>
          {state.map((item) => <div className='col-md-4'>
            <div className="card" >
              <img src={item.image} className="card-img-top" alt="..."/>
                <div className="card-body">
                  <h5 className="card-title">{item.title}</h5>
                  <p className="card-text"><h3>{item.price}</h3></p>

                </div>
            </div>
          </div>)}

        </div>
      </div>
    </>
  )
}
