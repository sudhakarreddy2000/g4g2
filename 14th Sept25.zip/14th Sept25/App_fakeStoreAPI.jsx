import React, { useState, useEffect } from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'

export default function App() {
  const[state, setState]=useState([])
useEffect(()=>{
 fetch('https://fakestoreapi.com/products')
  .then(response => response.json())
  //.then(data => console.log(data));
  .then(data => setState(data));
  },[])
  return (
    <>
    <ul>
   {/* {state.map((item)=><li>{item.title}</li>)} */}
  {state.map((item)=><img src={item.image} alt=""/>)}
   </ul>
    </>
  )
}
