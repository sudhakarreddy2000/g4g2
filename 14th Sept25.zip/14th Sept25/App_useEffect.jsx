import React, { useEffect } from 'react'
import '../node_modules/bootstrap/dist/css/bootstrap.css'

export default function App() {
useEffect(()=>{
    console.log("Mounted...")
  },[])


  return (
    <>
   
    </>
  )
}
