import { useState } from "react"
function App() {
  const [state, setState]=useState("Single page Applicaiton")
  const handler=()=>{
    setState("Geeks for Geeks")
  }
  return (
    <>
    <input type="text" value={state}/>
    <button onClick={handler}>update</button>
    </>
  )
}
export default App