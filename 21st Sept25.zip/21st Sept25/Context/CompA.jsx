import CompB from './CompB'
const CompA=()=>{
    return(
        <>
        <CompB />
        </>
    )
}
export default CompA