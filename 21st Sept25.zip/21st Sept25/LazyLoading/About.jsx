import React from 'react'

export default function About() {
  return (
    <>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
      <h1>Lazy loading example</h1>
    </>
  )
}
