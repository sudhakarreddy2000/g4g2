import React from 'react'
import CompC from './CompC'
export default function CompB(props) {
  return (
    <div>
      <h2>Component B</h2>
      <CompC  data={props.data}/>
    </div>
  )
}
