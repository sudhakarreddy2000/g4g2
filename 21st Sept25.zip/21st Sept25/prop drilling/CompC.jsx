import React from 'react'

export default function CompC(props) {
  return (
    <div>
      <h3>Component C</h3>
      <h2>{props.data}</h2>
    </div>
  )
}
