import React from 'react'
import CompA from './CompA'
export default function App() {
  let data="Single Page App"
  return (
    <div>
    <CompA data={data}/>
    </div>
  )
}
