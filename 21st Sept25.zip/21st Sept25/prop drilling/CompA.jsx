import React from 'react'
import CompB from './CompB'
export default function CompA(props) {
  return (
    <div>
      <h1>Component A</h1>
      <CompB data={props.data}/>
    </div>
  )
}
