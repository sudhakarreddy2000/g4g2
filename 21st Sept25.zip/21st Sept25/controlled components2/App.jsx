import { useState } from "react"
function App() {
  const [state, setState]=useState()
  const handler=(e)=>{
    setState(e.target.value)
  }
  return (
    <>
    <h3>{state}</h3>
    <input type="text" value={state} onChange={handler}/>
    </>
  )
}
export default App