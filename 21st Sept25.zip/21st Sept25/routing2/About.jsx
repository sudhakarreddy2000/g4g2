import React from 'react'

export default function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio vel est, eos excepturi itaque, perspiciatis ab veniam repellat perferendis numquam omnis tempora repellendus! Ipsa sunt, quis quisquam enim natus fugit libero qui totam, a incidunt nesciunt quo dolor neque cupiditate ratione, sequi iusto sed rerum impedit facere maiores. Explicabo quasi eum voluptates recusandae commodi consequuntur perferendis soluta aperiam perspiciatis quia quaerat iste, atque deleniti in omnis sapiente dolorum doloribus minus quod veniam, non laborum! Explicabo dicta a, quas magnam doloribus cum deleniti quis nihil in obcaecati, amet ab? Nisi aliquid perspiciatis eius? Rerum nobis dolore modi placeat tenetur iste nemo?
      </p>
    </div>
  )
}
