import React from 'react'

export default function Contact() {
  return (
    <div>
      <h1>Contact us page</h1>
        
    </div>
  )
}
