import {createRoot} from 'react-dom/client'
let obj=new Date();
let h=obj.getHours();
let message;
let cssStyle={ }
if(h<=12){
  message="Good morning"
  cssStyle.color="green"
}else if(h>12 && h<=17){
  message="Good Afternoon"
  cssStyle.color="red"
}else{
  message="Good Evening"
  cssStyle.color="orange"
}
createRoot(document.getElementById('root')).render(
  <>
  <h1 style={cssStyle}>Hello {message}</h1>
  </>
)