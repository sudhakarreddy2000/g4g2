let std1="Ajay"
let std2="Vijay"
let std3="Kiran"
let emp=["Rahul","Mohan","Vikram","Jadav"]
let people={
    name:'Peter',
    age:22,
    place:'UK'
}
function Test(){
    let uid="React"
    return uid
}


export default std1
export  {std2, std3,emp,people,Test}