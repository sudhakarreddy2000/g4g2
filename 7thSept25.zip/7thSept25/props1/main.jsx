import {createRoot} from 'react-dom/client'
import Comp1 from './Comp1'
createRoot(document.getElementById('root')).render(
  <>
<Comp1 name="Sudhakar" place="Hyderabad"/>
 </>
)