import React from 'react'

export default function Comp1(props) {
  return (
    <div>
      <h1>Component 1</h1>
      <h3>Hello {props.name} </h3>
      <h3>Place is {props.place}</h3>
    </div>
  )
}
