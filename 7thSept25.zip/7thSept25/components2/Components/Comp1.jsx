import React from 'react'
import pic from '../images/scene1.jpg'
export default function Comp1() {
  return (
    <div>
      <h1>Component1</h1>
    <img src={pic} alt=""/>
    </div>
  )
}

