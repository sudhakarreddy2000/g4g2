import React from 'react'

export default function Comp2() {
  return (
    <div>
      <h1>Component2</h1>
    </div>
  )
}
