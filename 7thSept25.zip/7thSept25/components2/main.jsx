import {createRoot} from 'react-dom/client'
import Comp1 from './Components/Comp1'
import Comp2 from './Components/Comp2'
import './style.css'
createRoot(document.getElementById('root')).render(
  <>
 <Comp1/>
 <Comp2/>
 </>
)