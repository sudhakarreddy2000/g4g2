import {createRoot} from 'react-dom/client'
import './style.css'
createRoot(document.getElementById('root')).render(
  <>
  <h1>Hello internal css</h1>
  <h1>Hello internal css</h1>
  <h1>Hello internal css</h1>
  <h1>Hello internal css</h1>
  <h1>Hello internal css</h1>
  <h1 className="txt">Hello internal css</h1>
  <p>
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus quaerat unde voluptatibus magnam, atque quidem. Voluptatum assumenda dolorem possimus repudiandae commodi explicabo beatae, vel ratione est! Officiis dolore voluptate reiciendis qui voluptas eligendi blanditiis consequatur. Ipsum, inventore repellat illo incidunt qui perferendis velit consequuntur rerum ipsa natus delectus vitae esse aspernatur perspiciatis? Aperiam, aliquid vero odio fugiat nam ipsum sit blanditiis voluptate eos vitae est consequatur distinctio nulla voluptatibus totam mollitia esse, corporis reprehenderit pariatur qui ut. Earum dignissimos, illum expedita autem ab eaque magnam voluptates ipsam dicta dolores, porro enim consectetur nemo ea rem sunt molestias eum suscipit ratione!
  </p>
  </>
)