function Comp1(){
    return(
        <>
        <h1>Welcome to components</h1>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos illum optio a culpa aliquid sed natus eius modi ipsum nemo tempora, eligendi illo nostrum quo recusandae tempore libero nesciunt praesentium! Ut minus voluptate quisquam natus voluptas tenetur deleniti doloribus enim dicta est vero impedit, cupiditate expedita provident animi esse quos saepe sequi suscipit? Quod, sit recusandae ratione explicabo, eum at dolor iure, placeat aperiam consequuntur veniam. Numquam sint nisi, ratione necessitatibus sunt eaque quae officia et in aspernatur voluptates iste, laboriosam tenetur ad possimus natus minima architecto laborum! Error suscipit dolorem corporis? Magni, architecto facere ut culpa tenetur expedita quia?
        </p>
        </>
    )
}

export default Comp1;