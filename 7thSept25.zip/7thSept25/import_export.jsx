import {createRoot} from 'react-dom/client'
import std1, {std2, std3, emp, people, Test} from './data.jsx'
createRoot(document.getElementById('root')).render(
  <>
<h3>{std1}</h3>
<h3>{std2}</h3>
<h3>{std3}</h3>
<h3>{emp}</h3>
<h3>{emp[0]}</h3>
<h3>{people.name}</h3>
<h3>{Test()}</h3>
  </>
)